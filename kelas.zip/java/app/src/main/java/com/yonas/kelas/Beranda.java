package com.yonas.kelas;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Beranda extends AppCompatActivity {
    private ListView listView;
    private String[] items = {"Nasi Goreng Biasa", "Nasi Goreng Ati Ampela", "Nasi Goreng Pete", "Nasi Goreng  Sosis", "Nasi Goreng Special"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda);

        listView = findViewById(R.id.listView);
        CustomAdapter adapter = new CustomAdapter(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selectedItem = items[position];

                if (selectedItem.equals("Nasi Goreng Biasa")) {
                    showItem1Dialog();
                } else {

                    Toast.makeText(Beranda.this, "Anda memilih " + selectedItem, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showItem1Dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Beranda.this);
        builder.setMessage("Nasi Goreng Biasa RP.15.000")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User mengklik OK
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
